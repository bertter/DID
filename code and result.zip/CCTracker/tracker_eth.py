import asyncio
import time
import json
from decimal import Decimal
from bs4 import BeautifulSoup

from tracker_base import Tracker
from utils import dropTailingZeros
from logger import log

from web3 import Web3
import pprint

class ETHTracker(Tracker):
	def __init__(self, coin, target, datasrc, linkFrom, apikeyStore, delay, debug):
		super().__init__(coin, target, datasrc, linkFrom, delay, debug)
		self.target = target.lower()

		self.apiurl = 'https://api.etherscan.io/api'
		self.keystore = apikeyStore

		self.wei = 1000000000000000000
		#self.web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io'))
		self.web3 = Web3(Web3.HTTPProvider('http://210.99.172.156:5458'))
		self.EIP20_ABI = json.loads('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_to","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_spender","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Approval","type":"event"}]')

	def validCheck(self, data, plainText):
		result = data if plainText else json.loads(data)

		if (plainText and result.find('alert-danger') > -1) or (not plainText and ('result' not in result or 'error' in result)):
			log.error(result)
			return False
		else:
			return True

	async def getExchangeInfo(self, target):
		queryString = 'SELECT owner FROM cctracker.{} WHERE address = "{}" AND coin = "{}" AND owner NOT LIKE "upbit hack%"'.format(self.tableName['owner'], target[2:], self.coin)
		exchangeInfo = await self.dbManager.dbExecute(queryString)

		if exchangeInfo:
			return exchangeInfo[0][0]
		else:
			suspectDict = self.loadDictionary('load_exchange.csv')
			if target in suspectDict:
				return suspectDict[target]
			else:
				return ''

	async def getTransactionCount(self, target):
		# 보낸 트랜잭션 횟수만 카운팅
		transCount = self.web3.eth.getTransactionCount(self.web3.toChecksumAddress(target))
		return transCount

	async def getBalance(self, target):
		balance = self.web3.eth.getBalance(self.web3.toChecksumAddress(target)) / self.wei
		return balance

	async def getTransactionData(self, target, limit, lastBlock = 0, currentTxCount = 0):
		txDatas = {}
		for i in range(8):
			queryString = '''SELECT txid, blocknum, txtime, sender, sender_amount, receiver, receiver_amount, total_amount, memo FROM ETH_transaction_{}
			                  WHERE blocknum > {} AND sender = "{}" OR receiver = "{}"'''.format('0'+str(i), lastBlock, target, target)
			if limit > 0:
				queryString += ' ORDER BY blocknum DESC LIMIT {}'.format(limit)
			txDatasFromDB = await self.dbManager.dbExecute(queryString)

			if not txDatasFromDB:
				continue

			for txData in txDatasFromDB:
				(txid, blocknum, txtime, sender, sender_amount, receiver, receiver_amount, total_amount, memo) = txData
				memo = json.loads(memo)

				txDatas[txid] = {
					'blocknumber': blocknum,
					'timestamp': int(txtime.replace(tzinfo=self.tzdata).timestamp()),
					'sender': sender,
					'receiver': receiver,
					'senderAmount': Decimal(sender_amount),
					'receiverAmount': Decimal(receiver_amount),
					'fee': Decimal(memo['gas']) * (Decimal(memo['gasPrice']) / Decimal(self.wei)).normalize(),
				}

				if limit > 0 and len(txDatas) > limit:
					return txDatas

		return txDatas

		'''
		data = await self.requestPost(self.apiurl, data = {
			'module': 'account',
			'action': 'txlist',
			'address': target,
			'startblock': lastBlock,
			'endblock': 'latest',
			'apikey': self.keystore.getKey(),
		})

		try:
			txlist = {}
			for txdata in data['result']:
				txlist[txdata['hash']] = {
					'timestamp': int(txdata['timeStamp']),
					'blocknumber': int(txdata['blockNumber']),
					'sender': txdata['from'],
					'receiver': txdata['to'],
					'senderAmount': Decimal(txdata['value']) / Decimal(self.wei),
					'receiverAmount': Decimal(txdata['value']) / Decimal(self.wei),
					'fee': Decimal(txdata['gasUsed']) * (Decimal(txdata['gasPrice']) / Decimal(self.wei)).normalize(),
				}
			return txlist
		except Exception as e:
			log.error(data)
			log.error(e)
		'''