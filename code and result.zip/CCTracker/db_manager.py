import asyncio
import aiomysql
import pymysql
import traceback, warnings
import time
from datetime import datetime, timezone, timedelta
from decimal import Decimal, getcontext

import store
from logger import log
from utils import dropTailingZeros
from db_config import dbConfig

class DBManager:
	def __init__(self, coin, config):
		self.coin = coin
		self.host = config['host']
		self.port = config['port']
		self.user = config['user']
		self.password = config['passwd']
		self.database = 'cctracker_v3_{}'.format(coin)

		self.is_init = False
		self.dbpool = None

		self.printProcTime = False

		self.timezone = 0
		self.timezoneString = "UTC"
		self.tzdata = timezone(timedelta(hours=self.timezone))

	async def init(self):
		if not self.is_init:
			self.is_init = True
			if not self.dbpool:
				self.dbpool = await self.makePool()
			await self.dbConnect()

	async def makePool(self):
		loop = asyncio.get_event_loop()
		dbpool = await aiomysql.create_pool(host = self.host,
												  port = self.port,
												  user = self.user,
												  password = self.password,
												  db = self.database,
												  loop = loop)
		return dbpool

	def setDatabasePool(self, pool):
		self.dbpool = pool


	async def dbConnect(self):
		try:
			async with self.dbpool.acquire() as conn:
				async with conn.cursor() as curs:
					await curs.execute('SET autocommit = 1')
					await curs.execute('SET time_zone = "{}"'.format(self.timezoneString))
					await curs.execute('USE {}'.format(self.database))
		except Exception as e:
			log.error(e)
			log.error(traceback.format_exc())
			raise OSError


	async def dbDisconnect(self):
		try:
			self.dbpool.close()
			await self.dbpool.wait_closed()
			self.is_init = False
		except Exception as e:
			log.error(e)
			log.error(traceback.format_exc())


	async def dbExecute(self, query, needDict = False):
		if not self.is_init:
			await self.init()

		starttime = time.time()
		result = None
		received = False

		while not received:
			data = None
			with warnings.catch_warnings():
				warnings.filterwarnings('error')
				try:
					async with self.dbpool.acquire() as conn:
						async with conn.cursor() as curs:
							await curs.execute(query)
							data = await curs.fetchall()
							received = True
				except (pymysql.err.OperationalError, pymysql.err.InterfaceError):
					log.error('Lost connection to MySQL server during query')
					await self.dbConnect()
				except Exception as e:
					print(e)
					log.error(query)
					log.error(e)
					log.error(traceback.format_exc())
					result = None
				else:
					if needDict:
						pass
					else:
						result = data

		processingtime = Decimal(time.time() - starttime).quantize(Decimal('.00001'))
		if self.printProcTime:
			log.info('-- {} - {}'.format(query, processingtime))
		return result