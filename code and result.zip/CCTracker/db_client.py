import asyncio
import aiomysql
import pymysql
import traceback, warnings
import time
from datetime import datetime, timezone, timedelta
from decimal import Decimal, getcontext

import store
from logger import log
from utils import dropTailingZeros
from db_config import dbConfig

class dbClient:
    def __init__(self, coin, config, tableName):
        self.coin = coin
        self.dbConfig = config
        self.tableName = tableName
        self.database = 'cctracker_v3_{}'.format(coin)

        self.tableShardCount = 8

        self.is_init = False
        self.dbpool = None

        self.printProcTime = True

        self.timezone = 0
        self.timezoneString = "UTC"
        self.tzdata = timezone(timedelta(hours=self.timezone))

    async def init(self):
        if not self.is_init:
            self.is_init = True
            if not self.dbpool:
                self.dbpool = await self.makePool()
            await self.dbConnect()

    async def makePool(self):
        loop = asyncio.get_event_loop()
        dbpool = await aiomysql.create_pool(host = self.dbConfig['host'],
                                            port = self.dbConfig['port'],
                                            user = self.dbConfig['user'],
                                            password = self.dbConfig['passwd'],
                                            db = self.database,
                                            loop = loop)
        return dbpool

    def setDatabasePool(self, pool):
        self.dbpool = pool
        self.is_init = True

    async def dbConnect(self):
        while True:
            conn = await self.dbpool.acquire()
            try:
                async with conn.cursor() as curs:
                    await curs.execute('USE {}'.format(self.database))
                    await curs.execute('SET autocommit = 1')
                    await curs.execute('SET time_zone = "{}"'.format(self.timezoneString))
            except pymysql.err.OperationalError as e:
                print(e)
                print('Connect error, retry')
                continue
            except Exception as e:
                log.error(e)
                log.error(traceback.format_exc())
                raise OSError
            else:
                self.dbpool.release(conn)
                break


    async def dbDisconnect(self):
        try:
            await asyncio.sleep(0)
            self.dbpool.close()
            await self.dbpool.wait_closed()
            self.is_init = False
        except Exception as e:
            log.error(e)
            log.error(traceback.format_exc())


    async def dbExecute(self, query, needDict = False):
        if not self.is_init:
            await self.init()

        starttime = time.time()
        result = None
        received = False

        while not received:
            data = None
            conn = None

            while not conn:
                try:
                    conn = await self.dbpool.acquire()
                except Exception as e:
                    log.error('Error on connection pool acquire - {}'.format(e))

            with warnings.catch_warnings():
                warnings.filterwarnings('error')
                try:
                    async with conn.cursor() as curs:
                        await curs.execute(query)
                        data = await curs.fetchall()
                        received = True
                except (pymysql.err.OperationalError, pymysql.err.InterfaceError, pymysql.err.InternalError) as e:
                    log.error('!! {}'.format(query[:77]))
                    log.error(e)

                except (pymysql.Warning, aiomysql.Warning) as e:
                    log.warning('!! {}'.format(query[:77]))
                    log.warning(e)

                except Exception as e:
                    print(e)
                    log.error(query)
                    log.error(e)
                    log.error(traceback.format_exc())
                    result = None
                else:
                    if needDict:
                        pass
                    else:
                        result = data

            self.dbpool.release(conn)
            
        processingtime = Decimal(time.time() - starttime).quantize(Decimal('.00001'))
        if self.printProcTime:
            printLength = 130#66
            queryString = query.replace('\n', ' ').replace('\t', '').replace('  ', '')[:printLength]
            space = '' if len(queryString) >= printLength else ' ' * (printLength - len(queryString))
            log.info('-- {}{} - {}'.format(queryString, space, processingtime))
            
        return result


    def tableNumber(self, key):
        return (int(str(key)[-1], 16) % self.tableShardCount)

    def transactionTable(self, txid):
        return '%s_%02d' % (self.tableName['transaction'], self.tableNumber(txid))

    async def getTransactionDataFromTxid(self, txids, lastblock):
        transDatas = {}

        tasks = []
        dbSelectors = []
        for tableSequence in list(range(self.tableShardCount)):
            dbSelector = dbWorker(self.coin, self.dbConfig, self.tableName, self.dbpool)
            dbSelectors.append(dbSelector)
            tasks.append(dbSelector.asyncGetTransactionDataFromTxid(txids, lastblock, tableSequence))

        asyncDatas = await asyncio.gather(*tasks)
        for data in asyncDatas:
            transDatas = dict(transDatas, **data)

        return transDatas
    
    async def asyncGetTransactionDataFromTxid(self, txids, lastblock, tableSequence):
        starttime = time.time()
        tableName = self.transactionTable(tableSequence)
        transDatas = {}

        filtedTxids = []
        for txid in txids:
            if self.tableNumber(txid) == tableSequence:
                filtedTxids.append(txid)

        queryString = '''SELECT txid, blocknum, txtime, sender, sender_amount, receiver, receiver_amount, total_amount
                           FROM {}
                          WHERE blocknum > {} AND txid IN ("{}")'''.format(tableName, lastblock, '","'.join(filtedTxids))
        transDatasFromDB = await self.dbExecute(queryString)

        for transData in transDatasFromDB:
            (txid, blocknum, txtime, sender, sender_amount, receiver, receiver_amount, total_amount) = transData
            transDatas[txid] = {}
            transDatas[txid]['sender'] = sender.split(',')
            transDatas[txid]['receiver'] = receiver.split(',')
            transDatas[txid]['sender_amount'] = list(map(Decimal, sender_amount.split(',')))
            transDatas[txid]['receiver_amount'] = list(map(Decimal, receiver_amount.split(',')))
            transDatas[txid]['total_amount'] = Decimal(str(total_amount))
            transDatas[txid]['blocknum'] = blocknum
            transDatas[txid]['txtime'] = txtime

        return transDatas
    
    
class dbWorker(dbClient):
    def __init__(self, coin, dbConfig, tableName, dbpool):
        super().__init__(coin, dbConfig, tableName)
        self.setDatabasePool(dbpool)

    async def checkTable(self):
        pass