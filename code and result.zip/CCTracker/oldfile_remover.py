import requests
import json
import calendar
from datetime import datetime, timedelta

#token from https://api.slack.com/web
_token = "xoxp-851032311664-853240086902-855280190261-fd7416ca49686f38df816d93c6a46443"
_domain = "YOUR SUB DOMAIN HERE"

if __name__ == '__main__':
    while True:
        files_list_url = 'https://slack.com/api/files.list'
        date = str(calendar.timegm((datetime.now() + timedelta(-30)).utctimetuple()))
        data = {"token": _token}#, "ts_to": date}
        response = requests.post(files_list_url, data = data)
        files = response.json()["files"]
        filesLength = len(files)
        if filesLength == 0:
            print("no have file")
            break

        for i in range(filesLength):
            f = files[i]
            print ("[{}/{}] Deleting file ".format(i+1, filesLength) + f["name"] + "...")
            timestamp = str(calendar.timegm(datetime.now().utctimetuple()))
            delete_url = "https://slack.com/api/files.delete?t=" + timestamp
            requests.post(delete_url, data = {
                "token": _token,
                "file": f["id"],
                "set_active": "true",
                "_attempts": "1"})
    print("DONE!")