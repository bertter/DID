dbConfig = {
    'host': '172.23.0.2',
    'port': 3306,
    'user': 'vats',
    'passwd': 'MariaDBPasswordVats!0046',
}