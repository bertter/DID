import asyncio
import aiohttp
import concurrent
import traceback
import json
import time
from utils import DecimalEncode
from logger import log

SERVER_CONNECTED = 1
SERVER_CONNECTING = 2
SERVER_DISCONNECTED = 3

class HttpClient:
    def __init__(self):
        self.headers = {}
        self.session = None
        self.isSleep = False
        self.sleepUntil = 0
        self.status = SERVER_DISCONNECTED

    async def makeSession(self):
        if self.status != SERVER_CONNECTING:
            print('make session')
            self.status = SERVER_CONNECTING
            #timeout = aiohttp.ClientTimeout(total=3600)
            #self.session = aiohttp.ClientSession(timeout=timeout)
            self.session = aiohttp.ClientSession()
            self.status = SERVER_CONNECTED

    async def closeSession(self):
        if self.session:
            await asyncio.sleep(0)
            await self.session.close()
            self.session = None
        self.status = SERVER_DISCONNECTED

    def validCheck(self, data, plainText):
        raise NotImplementedError()

    async def sleep(self, second = 0):
        currentTimestamp = int(time.time())

        '''
        if second:
            log.error('Current status is {} sleep, to {}, need {} secs sleep, current timestamp {}'.format('In' if self.isSleep else 'None', self.sleepUntil, second, currentTimestamp))
        else:
            log.error('sleep check, Current status is {} sleep'.format('In' if self.isSleep else 'None'))
        '''

        if self.isSleep:
            if self.sleepUntil > currentTimestamp:
                #log.error('keep sleep')
                return await asyncio.sleep(self.sleepUntil - currentTimestamp)
            else:
                self.isSleep = False
                self.sleepUntil = 0
                return None
        elif 0 < second:
            self.isSleep = True
            self.sleepUntil = int(time.time()) + second
            return await asyncio.sleep(second)

    async def requestPost(self, url, data = None, plainText = False):
        return await self.request(url, True, data, plainText)

    async def requestGet(self, url, data = None, plainText = False):
        return await self.request(url, False, data, plainText)

    async def request(self, url, methodPOST, data = None, plainText = False):
        #log.error('request ' + url)
        received = False
        while True:
            resp = None
            while True:
                try:
                    if self.status == SERVER_DISCONNECTED:
                        await self.makeSession()
                    elif self.status == SERVER_CONNECTING:
                        await asyncio.sleep(0)
                        continue
                    else:
                        await self.sleep()
                        if methodPOST:
                            resp = await self.session.post(url, data = data, headers = self.headers)
                        else:
                            resp = await self.session.get(url, params = data, headers = self.headers)
                except RuntimeError as e:
                    if e == 'Session is closed':
                        print('session is closed')
                        if self.status == SERVER_CONNECTED and self.session:
                            self.status = SERVER_DISCONNECTED
                            #await self.session.close()
                        self.session = None
                    else:
                        print(e)
                except concurrent.futures._base.TimeoutError:
                    print('!! concurrent futures timeout, on request')
                    log.error('!! concurrent futures timeout, on request')
                    log.error(traceback.format_exc())

                except (aiohttp.client_exceptions.ServerDisconnectedError,
                        aiohttp.client_exceptions.ClientConnectorError,
                        aiohttp.client_exceptions.ClientConnectionError,
                        aiohttp.client_exceptions.ClientOSError) as e:

                    if self.status == SERVER_CONNECTED and self.session:
                        print('!! {}'.format(type(e).__name__))
                        print('!! > Server Disconnected, try close session and re-connect')
                        log.error('!! {}'.format(type(e).__name__))
                        log.error('!! > Server Disconnected, try close session and re-connect')
                        log.error(traceback.format_exc())
                        self.status = SERVER_DISCONNECTED
                        await self.session.close()
                        #self.session = None

                    await asyncio.sleep(10)
                except Exception as e:
                    print('session error')
                    print(traceback.format_exc())
                    log.error('!!!!!!!! session error !!!!!!!!')
                    log.error(traceback.format_exc())
                    log.error(e)
                    log.error(url)
                    log.error(data)
                    log.error(self.headers)
                    input()
                    #await self.makeSession()
                else:
                    if resp:
                        break

            try:
                status = resp.status
                if 403 == status:
                    log.error('blocked, need sleep 5 secs')
                    await self.sleep(5)
                elif 524 == status:
                    log.error('request time out')
                else:
                    text = await resp.text()
                    check = self.validCheck(text, plainText)

                    if isinstance(check, bool) and check:
                        break
                    elif isinstance(check, list):
                        print('!! got error, need check')
                        log.error('!! got error, need check')
                        log.error(check)
                        log.error(url)
                        log.error(data)
                        await asyncio.sleep(30)
                    elif isinstance(check, int):
                        sleepTime = 5 if isinstance(check, bool) else check
                        log.error('no have result or get error, re-request after {} secs'.format(sleepTime))
                        await self.sleep(sleepTime)

            except aiohttp.client_exceptions.ClientPayloadError:
                print('!! Response payload is not completed, re-request')
                log.error('!! Response payload is not completed, re-request')
            except concurrent.futures._base.TimeoutError:
                print('!! concurrent futures timeout, on receiving response')
                log.error('!! concurrent futures timeout, on receiving response')
                log.error(traceback.format_exc())
            except Exception as e:
                log.error('!!!!!!! transfer error !!!!!!!')
                log.error(traceback.format_exc())
                log.error(e)
                log.error(data)
                log.error(text)
                log.error('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')

        #log.error('return')
        return text if plainText else json.loads(text)

class RPCClient(HttpClient):
    def __init__(self):
        super().__init__()
        self.headers = {'content-type': 'application/json',}

    async def requestBatchPost(self, url, data = None, plainText = False):
        for requestData in data:
            requestData.update({'jsonrpc': '2.0'})
        return await self.request(url, True, json.dumps(data), plainText)

    async def requestPost(self, url, data = None, plainText = False):
        data.update({'jsonrpc': '2.0'})
        return await self.request(url, True, json.dumps(data), plainText)

    async def requestGet(self, url, data = None, plainText = False):
        data.update({'jsonrpc': '2.0'})
        return await self.request(url, False, json.dumps(data), plainText)