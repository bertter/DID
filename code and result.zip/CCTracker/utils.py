def DecimalEncode(obj):
	if isinstance(obj, Decimal):
		if obj.is_zero():
			return '0'
		r = str(obj)
		return r.rstrip('0').rstrip('.') if '.' in r else r
		#return '%.8f' % (float(obj))
		#return str(obj)
	if isinstance(obj, datetime.datetime):
		return obj.isoformat(' ').split('.')[0]
	if isinstance(obj, Exception):
		return str(obj)
	raise TypeError

def dropTailingZeros(s):
	return s.rstrip('0').rstrip('.') if '.' in s else s