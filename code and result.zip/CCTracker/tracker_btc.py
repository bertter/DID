import asyncio
import time, datetime
from decimal import Decimal
from bs4 import BeautifulSoup

from tracker_base import Tracker
from utils import dropTailingZeros
from logger import log
import traceback

import pprint

class BTCTracker(Tracker):
    def __init__(self, coin, target, datasrc, linkFrom, apikeyStore, delay, debug):
        super().__init__(coin, target, datasrc, linkFrom, delay, debug)

    async def getExchangeInfo(self, target):
        queryString = 'SELECT owner FROM cctracker.{} WHERE address = "{}"'.format(self.tableName['owner'], target)
        exchangeInfo = await self.dbManager.dbExecute(queryString)
        if exchangeInfo:
            return exchangeInfo[0][0]
        else:
            return ''

    async def getTransactionCount(self, target):
        clusterId = await self.getClusterId([target])

        clusterAddress = []
        if(clusterId[target]):
            queryString = 'SELECT address, cid FROM {} WHERE cid = {}'.format(self.tableName['cluster_address'], clusterId[target])
            addressDatasFromDB = await self.dbManager.dbExecute(queryString)
            for addressData in addressDatasFromDB:
                (address, cid) = addressData
                clusterAddress.append(address)
        else:
            clusterAddress = [target]

        queryString = 'SELECT address, txcount FROM {} WHERE address in ("{}")'.format(self.tableName['address_info'], '","'.join(list(set(clusterAddress))))
        transDatasFromDB = await self.dbManager.dbExecute(queryString)
        transDatas = {}

        for transData in transDatasFromDB:
            (address, txcount) = transData
            transDatas[address] = txcount

        transCount = sum(transDatas.values())

        return transCount

    async def getBalance(self, target):
        clusterId = await self.getClusterId([target])
        
        clusterAddress = []
        if(clusterId[target]):
            queryString = 'SELECT address, cid FROM {} WHERE cid = {}'.format(self.tableName['cluster_address'], clusterId[target])
            addressDatasFromDB = await self.dbManager.dbExecute(queryString)
            for addressData in addressDatasFromDB:
                (address, cid) = addressData
                clusterAddress.append(address)
        else:
            clusterAddress = [target]

        queryString = 'SELECT address, txcount FROM {} WHERE address in ("{}")'.format(self.tableName['address_info'], '","'.join(list(set(clusterAddress))))
        transDatasFromDB = await self.dbManager.dbExecute(queryString)
        transDatas = {}

        for transData in transDatasFromDB:
            (address, balance) = transData
            transDatas[address] = balance

        balance = Decimal(sum(transDatas.values()))

        return balance
    
    async def getTransactionData(self, target, limit, lastBlock = 0, currentTxCount = 0):
        # get cluster id and master address by target address
        targetCid = await self.getClusterId([target])
        targetCid = targetCid[target]
        
        if targetCid:
            targetMaster = await self.getClusterInfo([targetCid])
            targetMaster = targetMaster[targetCid]
        else:
            targetCid = -1
            targetMaster = {'master': target}
        
        clusterData = {}
        clusterData[targetCid] = {'master': targetMaster['master'], 'list': []}
        
        # get address list by cid
        if targetCid > 0:
            queryString = 'SELECT address FROM {} WHERE cid = {}'.format(self.tableName['cluster_address'], targetCid)
            addressDatasFromDB = await self.dbManager.dbExecute(queryString)
            for address in addressDatasFromDB:
                clusterData[targetCid]['list'].append(address)
            clusterData[targetCid]['list'] = list(set(clusterData[targetCid]['list']))
        else:
            clusterData[targetCid]['list'] = [target]
        
        
        # get txid list by address
        queryString = 'SELECT txid FROM {} WHERE address IN ("{}")'.format(self.tableName['address_tx'], '","'.join(clusterData[targetCid]['list']))
        addressTxFromDB = await self.dbManager.dbExecute(queryString)
        txList = []
        for txid in addressTxFromDB:
            txList.append(txid[0])
        txList = list(set(txList))
        
        # get transaction data
        txDatas = await self.dbManager.getTransactionDataFromTxid(txList, lastBlock)
        
        # make address list related to the target address
        relationAddress = []
        for txid in txDatas:
            relationAddress.extend(txDatas[txid]['sender'])
            relationAddress.extend(txDatas[txid]['receiver'])
        relationAddress = set(relationAddress)
        relationAddress = list(relationAddress.difference(set(clusterData[targetCid]['list'])))
        
        
        ### relation data
        # relationClusterIds[address] = cid
        relationClusterIds = await self.getClusterId(relationAddress)
        relationClusterIdList = [cid for cid in set(relationClusterIds.values()) if cid]
        relationClusterIds[target] = targetCid
        # relationClusterDatas[cid] = {master, first_txtime, last_txtime}
        if relationClusterIdList:
            relationClusterDatas = await self.getClusterInfo(relationClusterIdList)
        else:
            relationClusterDatas = {}
        
        # make cluster data by related cid
        '''     
        queryString = 'SELECT address, cid FROM {} WHERE cid IN ("{}")'.format(self.tableName['cluster_address'], relationClusterIdList)
        addressDatasFromDB = await self.dbManager.dbExecute(queryString)
        addressDatas = {}
        for addressData in addressDatasFromDB:
            (address, cid) = addressData
            addressDatas[address] = cid
        '''
            
        for address in relationAddress:
            cid = relationClusterIds[address]
            
            if not cid:
                clusterIdList = [cid for cid in set(clusterData.keys()) if cid]
                cid = min(-1, min(clusterIdList) - 1)
                
                relationClusterIds[address] = cid
                master = address
            else:
                master = relationClusterDatas[cid]['master']
            
            if cid not in clusterData:
                clusterData[cid] = {'master': master, 'list': []}
            clusterData[cid]['list'].append(address)
            

        returnData = {}
        for txid in txDatas:
            txtime   = txDatas[txid]['txtime']
            blocknum = txDatas[txid]['blocknum']
            senderData   = {'address': None, 'amount': None}
            receiverData = {'address': [], 'amount': []}
            total_amount    = Decimal(str(txDatas[txid]['total_amount']))
            
            # 200908 클러스터링 완료 전까지는 임시코드.. sender 를 첫번째 주소로 조건없이 병합 (어차피 클러스터링 됨..)
            if target in txDatas[txid]['sender']:
                sender = target
            else:
                sender = txDatas[txid]['sender'][0]
            senderCid = relationClusterIds[sender]
            senderMaster = clusterData[senderCid]['master']
            senderAmount = sum(txDatas[txid]['sender_amount'])
            senderData['address'] = senderMaster
            senderData['amount'] = senderAmount
                    
            for i in range(len(txDatas[txid]['receiver'])):
                receiver = txDatas[txid]['receiver'][i]
                receiverCid = relationClusterIds[receiver]
                receiverMaster = clusterData[receiverCid]['master']
                receiverAmount = txDatas[txid]['receiver_amount'][i]
                receiverData['address'].append(receiverMaster)
                receiverData['amount'].append(receiverAmount)
            
            if len(senderData) > 0 and len(receiverData) > 0:
                returnData[txid] = {
                    'timestamp': int(time.mktime(txtime.timetuple())),
                    'blocknumber': blocknum,
                    'sender': senderData['address'],
                    'receiver': receiverData['address'],
                    'senderAmount': senderData['amount'],
                    'receiverAmount': receiverData['amount'],
                    'fee': sum(txDatas[txid]['sender_amount']) - sum(txDatas[txid]['receiver_amount']),
                }
        
        return returnData

    async def getClusterId(self, addressList):
        if not isinstance(addressList, list):
            addressList = [addressList]

        queryString = 'SELECT address, cid FROM {} WHERE address in ("{}")'.format(self.tableName['cluster_address'], '","'.join(list(set(addressList))))
        clusterIdListFromDB = await self.dbManager.dbExecute(queryString)
        clusterIdList = dict.fromkeys(addressList)
        
        for clusterData in clusterIdListFromDB:
            (address, cid) = clusterData
            clusterIdList[address] = cid

        return clusterIdList

    async def getClusterInfo(self, clusterIdList):
        if not isinstance(clusterIdList, list):
            if clusterIdList == -1:
                return []
            else:
                clusterIdList = [clusterIdList]
        elif isinstance(clusterIdList, list):
            if len(clusterIdList) == 0:
                return []
            elif len(clusterIdList) == 1 and clusterIdList[0] == -1:
                return []
            elif -1 in clusterIdList:
                clusterIdList.remove(-1)

        queryString = 'SELECT cid, master, first_txtime, last_txtime FROM {} WHERE isAlive = 1 and cid in ({})'.format(self.tableName['cluster_master'], ','.join(list(map(str, clusterIdList))))
        clusterInfoFromDB = await self.dbManager.dbExecute(queryString)
        clusterInfoList = dict.fromkeys(clusterIdList)

        for clusterInfo in clusterInfoFromDB:
            (cid, master, first_txtime, last_txtime) = clusterInfo
            clusterInfoList[cid] = {
                'master': master,
                'first_txtime': first_txtime,
                'last_txtime': last_txtime,
            }

        return clusterInfoList

    async def getTransactionIds(self, txnum):
        txnum_ = list(map(str, txnum))
        queryString = 'SELECT txnum, txid FROM {} WHERE txnum in ("{}")'.format(self.tableName['txnum'], '","'.join(txnum_))
        transactionsNumberFromDB = await self.dbManager.dbExecute(queryString)
        transactionsNumber = { data[0]: data[1] for data in transactionsNumberFromDB } # TXNUM: TXID
        return transactionsNumber