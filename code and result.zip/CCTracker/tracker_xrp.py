import asyncio
import time
import requests, json
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from bs4 import BeautifulSoup

from tracker_base import Tracker
from utils import dropTailingZeros
from logger import log
import store

class XRPTracker(Tracker):
	def __init__(self, coin, target, datasrc, linkFrom, apikeyStore, delay, debug):
		super().__init__(coin, target, datasrc, linkFrom, delay, debug)
		self.apiurl = 'https://data.ripple.com/v2'
		self.keystore = apikeyStore
		self.exchangeInfo = self.fetchExchangeInfo()
		self.inceptionDate = {}

	def validCheck(self, data, plainText):
		result = data if plainText else json.loads(data)

		if 'Rate limit exceeded' in data:
			return int(data.split(' ')[5].split('.')[0]) + 1

		if 'success' != result['result']:
			log.error(result['message'])
			return False
		return True

	def fetchExchangeInfo(self):
		if 'xrp_exchangeinfo' not in store.data:
			print('Fetching XRP Exchange Info')
			exchangeInfo = {}
			data = json.loads(requests.get('https://bithomp.com/api/v1/userinfo').text)
			for info in data['usersinfo']:
				exchangeInfo[info['address']] = info['name']
			store.data['xrp_exchangeinfo'] = exchangeInfo
		return store.data['xrp_exchangeinfo']

	async def getExchangeInfo(self, target):
		return '' if target not in self.exchangeInfo else self.exchangeInfo[target]

	async def getTransactionCount(self, target):
		if target not in self.inceptionDate:
			data = await self.requestGet(self.apiurl + '/accounts/' + target)
			self.inceptionDate[target] = data['account_data']['inception'].split('T')[0]

		data = await self.requestGet(self.apiurl + '/accounts/{}/stats/transactions'.format(target), data = {
			'start': self.inceptionDate[target],
		})
		for test in data['rows']:
			if 'Payment' not in test['type']:
				print('debug!!!!!!!!', data)
		return sum([row['type']['Payment'] for row in data['rows'] if 'Payment' in row['type']])

	async def getBalance(self, target):
		data = await self.requestGet(self.apiurl + '/accounts/{}/balances'.format(target))

		return Decimal([balance['value'] for balance in data['balances'] if 'XRP' == balance['currency']][0])

	async def getTransactionData(self, target, limit, astBlock = 0, currentTxCount = 0):
		txlist = {}

		data = await self.requestGet(self.apiurl + '/accounts/{}/transactions'.format(target), data = {
			'type': 'Payment',
			'limit': limit,
			'descending': 'true',
		})

		try:
			for txdata in data['transactions']:
				date = ':'.join(txdata['date'].split(':')[:-1])+txdata['date'].split(':')[-1]
				txlist[txdata['hash']] = {
					'timestamp': time.mktime(datetime.strptime(date, '%Y-%m-%dT%H:%M:%S%z').timetuple()), # 타임존 확인해야함
					'blocknumber': int(txdata['ledger_index']),
					'sender': txdata['tx']['Account'],
					'receiver': txdata['tx']['Destination'],
					'senderAmount': Decimal(txdata['tx']['Amount']) / 100000,
					'receiverAmount': Decimal(txdata['tx']['Amount']) / 100000,
					'fee': Decimal(txdata['tx']['Fee']) / 100000,
				}
		except Exception as e:
			log.error(data)
			log.error(e)

		return txlist


'''
리플의 트랜잭션 종류
https://xrpl.org/transaction-types.html
송금: Payment

- Exchange Info
https://bithomp.com/api/v1/userinfo

- Account Info
- 생성일시 key data['account_data']['inception'] = "2019-03-29T18:36:10Z"
https://data.ripple.com/v2/accounts/rfVingZtoqT4ExnCqgTadEyCSqQWkekeys

- Account Transaction Status
나간 트랜잭션 데이터만 보여줌
default limit is 200, maximum is 1000
https://data.ripple.com/v2/accounts/rfVingZtoqT4ExnCqgTadEyCSqQWkekeys/stats/transactions?start=2019-03-21&limit=10

- balance
https://data.ripple.com/v2/accounts/rfVingZtoqT4ExnCqgTadEyCSqQWkekeys/balances

- Payment Info
https://data.ripple.com/v2/accounts/rfVingZtoqT4ExnCqgTadEyCSqQWkekeys/transactions?type=Payment&limit=50&descending=true
'''