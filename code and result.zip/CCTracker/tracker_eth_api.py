import asyncio
import time
import json
from decimal import Decimal
from bs4 import BeautifulSoup

from tracker_base import Tracker
from utils import dropTailingZeros
from logger import log

class ETHAPITracker(Tracker):
	def __init__(self, coin, target, datasrc, linkFrom, apikeyStore, delay, debug):
		super().__init__(coin, target, datasrc, linkFrom, delay, debug)
		self.target = target.lower()

		self.apiurl = 'https://api.etherscan.io/api'
		self.keystore = apikeyStore
		self.wei = 1000000000000000000

	def validCheck(self, data, plainText):
		result = data if plainText else json.loads(data)

		if (plainText and result.find('alert-danger') > -1) or (not plainText and ('result' not in result or 'error' in result)):
			log.error(result)
			return False
		else:
			return True

	async def getExchangeInfo(self, target):
		data = await self.requestPost('https://etherscan.io/address/%s' % target, plainText = True)

		try:
			bs = BeautifulSoup(data, 'lxml')
		except TypeError:
			raise TypeError

		exchangeInfo = bs.find('a', class_='u-label--info')
		secondaryInfo = bs.find('a', class_='u-label--secondary')
		overviewLabel = bs.find('span', class_='u-label--secondary')

		exchange = ''
		if secondaryInfo:
			if exchangeInfo:
				exchange = exchangeInfo.text.rstrip(' ')
			elif overviewLabel:
				exchange = overviewLabel.text.split(' ')[0].split('.')[0]

		return exchange

	async def getTransactionCount(self, target):
		data = await self.requestPost('https://etherscan.io/address/%s' % target, plainText = True)

		try:
			bs = BeautifulSoup(data, 'lxml')
		except TypeError:
			raise TypeError

		text = bs.find('p', class_='mb-lg-0')

		transCount = 0
		if text.find('a'):
			transCount = text.find('a').text
		else:
			transCount = text.text.split(' ')[1]

		return int(transCount.replace(',', ''))

	async def getBalance(self, target):
		data = await self.requestPost(self.apiurl, data = {
			'module': 'account',
			'action': 'balance',
			'address': target,
			'tag': 'latest',
			'apikey': self.keystore.getKey(),
		})
		try:
			return Decimal(data['result']) / Decimal(self.wei)
		except Exception as e:
			print(target)
			print(data)
			log.error(data)
			log.error(e)

	async def getTransactionData(self, target, limit, lastBlock = 0, currentTxCount = 0):
		data = await self.requestPost(self.apiurl, data = {
			'module': 'account',
			'action': 'txlist',
			'address': target,
			'startblock': lastBlock,
			'endblock': 'latest',
			'apikey': self.keystore.getKey(),
		})

		try:
			txlist = {}
			for txdata in data['result']:
				txlist[txdata['hash']] = {
					'timestamp': int(txdata['timeStamp']),
					'blocknumber': int(txdata['blockNumber']),
					'sender': txdata['from'].lower(),
					'receiver': txdata['to'].lower(),
					'senderAmount': Decimal(txdata['value']) / Decimal(self.wei),
					'receiverAmount': Decimal(txdata['value']) / Decimal(self.wei),
					'fee': Decimal(txdata['gasUsed']) * (Decimal(txdata['gasPrice']) / Decimal(self.wei)).normalize(),
				}
			return txlist
		except Exception as e:
			log.error(data)
			log.error(e)