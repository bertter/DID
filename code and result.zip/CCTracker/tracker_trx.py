import asyncio
import time
from decimal import Decimal, ROUND_HALF_UP
from bs4 import BeautifulSoup

from tracker_base import Tracker
from utils import dropTailingZeros
from logger import log

class TRXTracker(Tracker):
	def __init__(self, coin, target, datasrc, linkFrom, apikeyStore, delay, debug):
		super().__init__(coin, target, datasrc, linkFrom, delay, debug)
		self.apiurl = 'https://apilist.tronscan.org/api'
		self.keystore = apikeyStore

	def validCheck(self, data, plainText):
		if data.find('An error occurred') > -1:
			return False
		return True

	async def getExchangeInfo(self, target):
		return ''

	async def getTransactionCount(self, target):
		data = await self.requestGet(self.apiurl + '/transaction', data = {
			'sort': '-timestamp',
			'count': 'true',
			'limit': 0,
			'start': 0,
			'address': target,
		})
		return int(data['rangeTotal'])

	async def getBalance(self, target):
		data = await self.requestGet(self.apiurl + '/account', data = {
			'address': target,
		})

		trxBalance = 0
		tokenBalances = []
		for bal in data['balances']:
			balance = Decimal(Decimal(bal['balance']) / Decimal(1000000))

			if '_' == bal['name']:
				trxBalance = balance
			elif 'priceInTrx' in bal:
				tokenBalances.append(Decimal(balance * Decimal(bal['priceInTrx'])).quantize(Decimal('.000001'), rounding=ROUND_HALF_UP))

		tokenBalance = sum(tokenBalances)

		#trxBalance = Decimal([ bal['balance'] for bal in data['balances'] if bal['name'] == '_' ][0]) / Decimal(1000000)
		#tokenBalance = sum([ Decimal(Decimal(bal['balance']) / Decimal(1000000) * Decimal(bal['priceInTrx'])).quantize(Decimal('.000001'), rounding=ROUND_HALF_UP) for bal in data['balances'] if bal['name'] != '_' ])

		return Decimal(trxBalance + tokenBalance)

	async def getTransactionData(self, target, limit, lastBlock = 0, currentTxCount = 0):
		txlist = {}

		data = await self.requestGet(self.apiurl + '/transaction', data = {
			'sort': '-timestamp',
			'count': 'true',
			'limit': limit,
			'start': currentTxCount,
			'token': '_',
			'address': target,
		})

		try:
			for txdata in data['data']:
				txlist[txdata['hash']] = {
					'timestamp': int(txdata['timestamp']) / 1000,
					'blocknumber': int(txdata['block']),
					'sender': txdata['ownerAddress'],
					'receiver': txdata['toAddress'],
					'senderAmount': Decimal(txdata['contractData']['amount']) / 1000000,
					'receiverAmount': Decimal(txdata['contractData']['amount']) / 1000000,
					'fee': 0 if '' == txdata['fee'] else int(txdata['fee']),
				}
		except Exception as e:
			log.error(data)
			log.error(e)

		data = await self.requestGet(self.apiurl + '/transfer', data = {
			'sort': '-timestamp',
			'count': 'true',
			'limit': self.transactionLimit,
			'start': currentTxCount,
			'token': '_',
			'address': target,
		})

		try:
			for txdata in data['data']:
				txlist[txdata['transactionHash']] = {
					'timestamp': int(txdata['timestamp']) / 1000,
					'blocknumber': int(txdata['block']),
					'sender': txdata['transferFromAddress'],
					'receiver': txdata['transferToAddress'],
					'senderAmount': Decimal(txdata['amount']) / 1000000,
					'receiverAmount': Decimal(txdata['amount']) / 1000000,
					'fee': 0,
				}
		except Exception as e:
			log.error(data)
			log.error(e)

		return txlist