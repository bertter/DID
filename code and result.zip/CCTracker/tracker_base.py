import os
import asyncio
import traceback
import pyanx
import requests
import json
import pprint
import time
import copy
import collections
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from openpyxl import load_workbook
from gmail import GMailWorker, Message
from http_client import HttpClient
from manager import tracker_manager
from db_client import dbClient
from db_config import dbConfig
from config import transactionLimits, watchingBalances
from config import slackWebHookURL, slackBotAccessToken, slackAlertChannel
from config import gmailUsername, gmailAPPPassword
from config import requestEmailContents, requestDocument, exchangeEmails, investigatorEmails, highlight
from utils import dropTailingZeros
from logger import log

import store

class Tracker(HttpClient):
    def __init__(self, coin, target, datasrc, linkFrom, delay, debug = False):
        super().__init__()

        self.debug = debug

        self.onlySuspect = True
        self.trackingHopLimit = 5

        self.startTimestamp = int(time.time())#int(datetime.utcnow().timestamp()) #
        #self.startTimestamp = int(time.mktime(datetime.strptime('2019-12-06 06:46:00', '%Y-%m-%d %H:%M:%S').timetuple()))
        self.caseTimestamp = 0

        self.coin = coin
        self.target = target
        self.origin = None # UTXO 코인을 위한 master 주소
        self.linkFrom = linkFrom if linkFrom else None
        self.delay = delay
        self.fromdb = True if datasrc == 'DB' else False

        self.transactionLimit = transactionLimits[self.coin]
        self.watchingBalances = watchingBalances[self.coin]
        
        self.sendSlackAlert = True
        self.sendEmailAlert = False

        self.slackAlertChannel = slackAlertChannel
        self.slackWebHookURL = slackWebHookURL
        self.slackBotAccessToken = slackBotAccessToken
        self.requestEmailContents = requestEmailContents
        self.requestDocument = requestDocument
        self.exchangeEmails = exchangeEmails
        self.investigatorEmails = investigatorEmails
        self.highlight = highlight

        self.dbConfig = dbConfig
        self.dbManager = None

        self.targetList = {}
        self.txList = {}
        self.txData = {}

        self.alertList = [self.target]
        self.txAlert = []
        self.is_watching = True

        if self.debug and self.target in store.data:
            if 'targetList' in store.data[self.target]:
                print('a')
                self.targetList = copy.deepcopy(store.data[self.target]['targetList'])
            if 'txList' in store.data[self.target]:
                self.txList = copy.deepcopy(store.data[self.target]['txList'])
            if 'txData' in store.data[self.target]:
                self.txData = copy.deepcopy(store.data[self.target]['txData'])
            if 'alertList' in store.data[self.target]:
                print('b')
                self.alertList = copy.deepcopy(store.data[self.target]['alertList'])


        self.timezone = 0
        self.tzdata = timezone(timedelta(hours=self.timezone))

        self.dbName = 'cctracker_v3_{}'.format(self.coin)
        self.tableName = {
            'address_tx': '{}_address_tx'.format(coin),
            'address_info': '{}_address_info'.format(coin),
            'status': '{}_status'.format(coin),
            'transaction': '{}_transaction'.format(coin),
            'cluster_master': '{}_cluster_master'.format(coin),
            'cluster_address': '{}_cluster_address'.format(coin),
            'txnum': '{}_txnum'.format(coin),
            'owner': 'coin_owner',
        }

    async def getTransactionCount(self, target):
        raise NotImplementedError()

    async def getBalance(self, target):
        raise NotImplementedError()

    async def getTransactionData(self, target, lastBlock = 0):
        raise NotImplementedError()

    async def Terminate(self):
        store.data['running'] = False
        await self.closeSession()

        if self.fromdb and self.dbManager:
            await self.dbManager.dbDisconnect()

    async def Process(self):
        tracking_hop = 0
        starttime = time.time()

        if os.path.exists('timestamp.last'):
            with open('timestamp.last', 'rt') as last:
                data = last.read()
                if len(data) > 0:
                    self.startTimestamp = int(data)

        while store.data['running']:
            try:
                self.is_watching = True

                if not self.targetList or len(self.targetList) == 0:
                    self.targetList = {self.target: {'balance': 0, 'exchange': '', 'lastblock': 0}}
                targetCount = len(self.targetList)

                targetList = []
                if self.onlySuspect:
                    targetList = self.alertList
                else:
                    targetList = self.targetList

                trackingTarget = []
                for target in targetList:
                    if target == self.target:
                        trackingTarget.append(target)
                    elif '' == self.targetList[target]['exchange']:
                        trackingTarget.append(target)

                tasks = [asyncio.ensure_future(self.Tracking(target)) for target in trackingTarget]
                await asyncio.gather(*tasks)

                if len(self.targetList) > 1:
                    self.saveResultCSV()
                    self.saveChart()
                    suspectsBalance = self.saveAlertList()

                    # 알람 목록을 확인
                    if len(self.txAlert) > 0:
                        txAlert = list(set(copy.deepcopy(self.txAlert)))
                        for txid in txAlert:
                            for address in self.txData[txid]['receiver']:
                                # 수신자가 의심 목록에 없을것 && 해당 주소의 최초 트랜잭션이 범행 timestamp 이후일것 => 해커 이외(거래소, 3자)로의 출금만 알린다
                                firstTimestamp = min([self.txList[address][txid] for txid in self.txList[address]])
                                #if firstTimestamp < self.caseTimestamp:

                                # 최초 tx 가 범행 이전 => 해커가 만든 주소일 가능성이 낮은 경우에 알람
                                if False and firstTimestamp > self.caseTimestamp:
                                    continue

                                # 수신자가 알림목록(해커의심)에 없을 경우에만 알람()
                                if False and address in self.alertList:
                                    continue

                                check = self.Suspect(address, 0, txid = txid)
                                if check == -1:
                                    print('txid: ', txid)
                                    pprint.pprint(self.alertList)
                                    input()

                            #self.txAlert.remove(txid)

                        '''
                        for exchangeCheck in self.txData[self.txAlert]['receiver']:
                            ## 거래소로 추정되는 주소에만 알람
                            #if exchangeCheck in self.targetList and self.targetList[exchangeCheck]['exchange'] != '':
                            ## 모든 주소에 대해 전송하도록
                            #if exchangeCheck in self.targetList:
                                self.Suspect(exchangeCheck, 0, txid = self.txAlert)
                        '''

                    tracking_hop += 1
                    # tracking_hop 이 특정 기준을 넘어서면, 경고 메시지 출력하고 1. 중단 2. 단순화 3. 계속진행 결정해야함

                    if targetCount != len(self.targetList):
                        print('[STEP {}] {} new targets found'.format(tracking_hop, len(self.targetList) - targetCount))
                    elif self.debug:
                        # 디버그 모드일때는 타겟 갯수 변화 없으면 추적 중단
                        print('No new targets')
                        store.data['running'] = False

                    if self.debug and tracking_hop == self.trackingHopLimit:
                        # debug 모드일때는 5스텝 탐색하고 추적 중단
                        store.data['running'] = False

                delay = self.delay if self.is_watching else 1
                await asyncio.sleep(delay)

                if tracker_manager.getAliveCount() == 0 and tracker_manager.getTotalCount() > 1:
                    print('No alive targets')
                    store.data['running'] = False
            except Exception as e:
                print('error on processing')
                print(traceback.format_exc())
                input()


        processingtime = Decimal(time.time() - starttime).quantize(Decimal('.01'))
        print('processing time:', processingtime)

        # await self.Terminate()
        await self.closeSession()
        if self.fromdb:
            await self.dbManager.dbDisconnect()

        lastTimestamp = self.startTimestamp
        with open('timestamp.last', 'wt') as last:
            for txid in self.txData:
                lastTimestamp = max(lastTimestamp, self.txData[txid]['timestamp'])
            last.write(str(lastTimestamp))

        if self.debug:
            print('#'*25)
            print('#'*25)
            dateformat = '%Y-%m-%dT%H:%M:%S%z'
            ksttz = timezone(timedelta(hours=9))
            txKSTDatetime = datetime.fromtimestamp(lastTimestamp, ksttz)
            txKSTDatetimeString = txKSTDatetime.strftime(dateformat)
            print(txKSTDatetimeString)
            print('hacker\'s balance:', suspectsBalance.quantize(Decimal('0')))
            print('#'*25)
            print('#'*25)

            #store.data[self.target] = {}
            #store.data[self.target]['targetList'] = self.targetList
            #store.data[self.target]['txList'] = self.txList
            #store.data[self.target]['txData'] = self.txData
            #store.data[self.target]['alertList'] = self.alertList

    async def Tracking(self, target):
        tracker_manager.touch(target)

        if self.fromdb and not self.dbManager:
            self.dbManager = dbClient(self.coin, self.dbConfig, self.tableName)
            await self.dbManager.init()

        while not self.dbManager.dbpool:
            await asyncio.sleep(0.1)

        try:
            '''
            if target == self.target:
                ##print('self', target)
                self.targetList[target]['exchange'] = await self.getExchangeInfo(target)
            '''

            # exchange 정보도 매회 갱신 (거래소가 아닐경우만 들어온다는게 문제인데..)
            self.targetList[target]['exchange'] = await self.getExchangeInfo(target)
            # balance 는 매회 갱신
            self.targetList[target]['balance'] = await self.getBalance(target)
            # ETH 의 경우 트랜잭션 카운트 가져오는 RPC CALL 이 outgoing 트랜잭션만 카운팅함
            transactionCount = await self.getTransactionCount(target) if self.transactionLimit > 0 else 0
            lastBlock = self.targetList[target]['lastblock']

            # 추적 대상 주소의 트랜잭션이 0인 경우, 바로 슬립 200910
            if target == self.target and transactionCount == 0:
                print('{}({}....{}) tx count is zero'.format(self.coin, target[:5], target[-5:]))
                tracker_manager.sleep(target)
                return

            '''
            # 의심스러운 (거래소 등) 주소 체크, 더이상 진행하지 않는다 => 거래소 주소로 확인되었더라도, 트랜잭션 횟수가 기준 이하라면 따라갈 필요가 있음.. 주석 190929
            if '' != self.targetList[target]['exchange']:
                self.Suspect(target, transactionCount)
                return
            '''

            '''
            # 잔고 0인 주소 추적 중단
            if self.targetList[target]['balance'] == 0:
                print('target balance is 0')
                self.targetList[target]['exchange'] = '0'
                tracker_manager.die(target)
                return
            '''

            # 트랜잭션 횟수가 기준 이상이라면, 의심스러운 주소로 체크, 해당 주소 추적 중단
            if self.transactionLimit > 0 and (self.transactionLimit <= transactionCount or \
                    ((target in self.txList) and (self.transactionLimit <= len(self.txList[target])))):
                if target != self.target: # 타겟이 시작 주소 일때는 트랜잭션 많더라도 무조건 따라가도록.
                    if self.targetList[target]['exchange'] == '':
                        self.targetList[target]['exchange'] = 'Unknown'
                    ##
                    targetData = await self.getTransactionData(target, self.transactionLimit, lastBlock)
                    self.targetList[target]['lastblock'] = max([ targetData[txid]['blocknumber'] for txid in targetData ])
                    ##
                    self.Suspect(target, max(len(self.txList[target]), transactionCount))
                    return

            targetTxCount = 0 if target not in self.txList else len(self.txList[target])
            requestLimit = self.transactionLimit if target != self.target else 0 # 시작 주소일때는 모든 트랜잭션 다 받아온다
            txData = await self.getTransactionData(target, requestLimit, lastBlock)
        except Exception as e:
            print(e)
            print(traceback.format_exc())
            print('Error, on receiving data')
            tracker_manager.die(target)
            return

        try:
            newTargetList = []
            newAlertList = []
            newTxidList = []

            txData = collections.OrderedDict(sorted(txData.items(), key=lambda v:v[1]['timestamp']))
            txDataKeys = list(txData.keys())

            for txid in txData:
                ##print('txid', txid)

                # 특정시간 이전 트랜잭션은 무시
                if txData[txid]['timestamp'] < self.caseTimestamp: # or txData[txid]['receiverAmount'] == 0:
                    continue

                # tracker_COIN 에서 넘어온 receiver, list wrapping 보정
                if not isinstance(txData[txid]['receiver'], list):
                    txData[txid]['receiver'] = [txData[txid]['receiver']]
                    ##print('receiver list wrap', txData[txid]['receiver'])
                if not isinstance(txData[txid]['receiverAmount'], list):
                    txData[txid]['receiverAmount'] = [txData[txid]['receiverAmount']]
                    ##print('receiverAmount list wrap', txData[txid]['receiverAmount'])

                # txid 기준, 새로운 tracnsaction 있으면, self.txData 에 추가
                if txid not in self.txData:
                    self.txData[txid] = txData[txid]

                    # 추적프로그램 실행 이후 발생한 트랜잭션인 경우에만 알람 목록에 추가 (alertlist 는 이후 갱신되므로, 알람 시점에 다시 분기)
                    if txData[txid]['timestamp'] > self.startTimestamp:
                        self.txAlert.append(txid)


                # sender address 기준, 새로운 transaction 있으면, self.txList 에 append
                # TODO 191129 sender 는 list 아님, 아래 로직 변경 필요, 200908 코멘트 추가 - UTXO는 sender 소유 비밀키 1개,
                txfrom = txData[txid]['sender']
                ##print('txfrom', txfrom)
                # UTXO 코인의 경우, 최초 타겟 주소가 master 주소로 바뀌어 돌아옴, master 주소를 따로 저장, 200908 코멘트 추가 - 왜 저장하지?
                if 1 == len(txfrom):
                    self.origin = txfrom
                    
                if txfrom not in self.txList:
                    ##print('txList, new from')
                    self.txList[txfrom] = {}
                    newTargetList.append(txfrom)

                if txid not in self.txList[txfrom]:
                    ##print('txList, new from tx')
                    self.txList[txfrom][txid] = txData[txid]['timestamp']


                # receiver address 기준, 새로운 tracnsaction 있으면, self.txList 에 append
                txto = txData[txid]['receiver']
                ##print('txto', txto)

                for address in txto:
                    if address not in self.txList:
                        self.txList[address] = {}

                    if txid not in self.txList[address]:
                        self.txList[address][txid] = txData[txid]['timestamp']
                        newTxidList.append(txid)

                    # 새로운 주소라면
                    if address != self.target and address not in self.targetList and address not in newTargetList:
                        newTargetList.append(address)

                    if txfrom in self.alertList and address not in self.alertList and address not in newAlertList:
                        newAlertList.append(address)

                newTxidList = list(set(newTxidList))
                newTargetList = list(set(newTargetList))

                self.targetList[target]['lastblock'] = max(self.targetList[target]['lastblock'], txData[txid]['blocknumber'])


            # 트랜잭션 횟수가 기준 이상이라면, 의심스러운 주소로 체크, 연결 주소들은 새로운 타겟으로 추가하지 않음 (단, 시작주소가 아닐때)
            # + 해당 주소의 최초 트랜잭션이 최초 타겟의 출금 흐름에서 파생된 주소가 아니라면 추적 중단
            if self.transactionLimit > 0 and self.transactionLimit <= len(newTxidList) and target != self.target and txData[txDataKeys[0]]['sender'] not in self.alertList:
                print('suspicious address %s trans count is %d' % (target, len(txData)))

                exchange = await self.getExchangeInfo(target)
                targetData = await self.getTransactionData(target, self.transactionLimit)

                self.targetList[target]['exchange'] = exchange if exchange != '' else 'Unknown'
                self.targetList[target]['balance'] = await self.getBalance(target)
                self.targetList[target]['lastblock'] = max([ targetData[txid]['blocknumber'] for txid in targetData ])

                self.Suspect(target, len(txData))
            else:
                if 1 <= len(newTargetList):
                    self.is_watching = False
                    # 새로운 타겟 초기화
                    ##print('new', newTargetList)

                    for newTarget in newTargetList:
                        exchange = await self.getExchangeInfo(newTarget)
                        balance = await self.getBalance(newTarget)
                        self.targetList[newTarget] = {'balance': balance, 'exchange': exchange, 'lastblock': 0}

                # 최초 타겟에서 출금 흐름 연관된것만 목록으로 관리 (주요 알람 대상 확장)
                if 1 <= len(newAlertList):
                    self.alertList = list(set(self.alertList + newAlertList))

            tracker_manager.sleep(target)

        except Exception:
            print('Error, on processing data')
            print(traceback.format_exc())
            tracker_manager.die(target)
            return

    def Suspect(self, address, transactionCount, txid = None):
        if address not in self.targetList:
            print('address: ', address)
            print('txid: ', txid)
            return -1

        exchange = self.targetList[address]['exchange']
        txTotalCount = max(len(self.txList[address]), transactionCount)
        tracker_manager.suspect(address)
        print('suspicious address %s trans count is %d (%s)' % (address, txTotalCount, exchange))


        if not txid:
            txid = [txid for txid in self.txList[address] if self.txList[address][txid] == max(self.txList[address].values())][0]

        if not self.debug and self.startTimestamp > self.txData[txid]['timestamp']:
            tzdata = timezone(timedelta(hours=0))
            dateformat = '%Y-%m-%dT%H:%M:%S%z'
            datestr = datetime.fromtimestamp(self.startTimestamp, tzdata).strftime(dateformat)
            #print(self.startTimestamp, datestr)
            datestr = datetime.fromtimestamp(self.txData[txid]['timestamp'], tzdata).strftime(dateformat)
            #print(txid, self.txData[txid]['timestamp'], datestr)
            #print('return')
            return

        if txid not in self.txAlert:
            return
        else:
            self.txAlert.remove(txid)


        txFrom = self.txData[txid]['sender']
        txTo = self.txData[txid]['receiver']
        txFromString = ''
        txToString = ''
        txSendAmount = self.txData[txid]['senderAmount']
        txReceiveAmount = self.txData[txid]['receiverAmount']

        timestamp = self.txList[address][txid] # UTC
        dateformat = '%Y-%m-%dT%H:%M:%S%z'
        txDatetime = datetime.fromtimestamp(timestamp, self.tzdata)
        txDatetimeString = txDatetime.strftime(dateformat)

        ksttz = timezone(timedelta(hours=9))
        txKSTDatetime = datetime.fromtimestamp(timestamp, ksttz)
        txKSTDatetimeString = txKSTDatetime.strftime(dateformat)

        suspectDict = self.loadDictionary('load_suspect.csv')
        if address == txFrom:
            txFromString = '{}'.format(txFrom)
            txToString = ','.join(txTo)
            if exchange != '':
                txFromString += ' ({})'.format(exchange)
            if address in suspectDict:
                txFromString += ' / {}'.format(suspectDict[address])
        elif address in txTo:
            txFromString = '{}'.format(txFrom)
            txToString = '{}'.format(address)
            if exchange != '':
                txToString += ' ({})'.format(exchange)
            if address in suspectDict:
                txToString += ' / {}'.format(suspectDict[address])


        messageBlock = None
        if address in self.alertList:
            messageBlock = json.dumps([
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "{} 추적 중, 피의자 주소에서 출금 되었음을 확인\n*<https://etherscan.io/tx/{}|Detail Link (etherscan)>*".format(self.coin, txid)
                        }
                    },
                    {
                        "type": "divider"
                    },
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "*TxID:* {}\n*보낸 주소:* {}\n*받는 주소:* {}\n*수량:* {}".format(txid, txFromString, txToString, txSendAmount)
                        }
                    },
                    {
                        "type": "context",
                        "elements": [
                            {
                                "type": "mrkdwn",
                                "text": "UTC: {}".format(txDatetimeString)
                            },
                            {
                                "type": "mrkdwn",
                                "text": "KST: {}".format(txKSTDatetimeString)
                            }
                        ]
                    },
                    {
                        "type": "divider"
                    }
                ])

        elif False:
            txTypeString = ''
            txAmount = 0

            if address == txFrom:
                txTypeString = '에서 출금'
                txAmount = txSendAmount
                txFromString = txFrom
                txToString = ', '.join(txTo)
            elif address in txTo:
                txTypeString = '로 입금'
                txAmount = txReceiveAmount[txTo.index(address)]
                txFromString = txFrom
                txToString = address

            alertMessagePayload['text'] = u'''
                {} 추적 중, 거래소 {} {} 되었음을 확인.
                트랜잭션 횟수 : {} ({})
                트랜잭션 일시 : {}
                TXID : {}
                수량 : {}
                보낸 주소 : {}
                받은 주소 : {}
            '''.format(self.coin, exchange, txTypeString, txTotalCount, address, txDatetimeString, txid, txAmount, txFromString, txToString).replace('    ', '')
            # <https://etherscan.io/tx/{}|Detail Link>

            requests.post(self.slackWebHookURL, data=json.dumps(alertMessagePayload), headers={'Content-Type': 'application/json'})

        if messageBlock:
            if self.sendSlackAlert and self.slackWebHookURL:
                try:
                    self.saveChart()
                    dirname = 'result/{}_{}/'.format(self.coin, self.target)
                    filename = '{}_{}_onlySuspect.anx'.format(self.coin, self.target)

                    alertMessagePayload = {
                        'token': slackBotAccessToken,
                        'channel': self.slackAlertChannel,
                        'username': 'VATracker',
                        'icon_url': 'https://a.slack-edge.com/80588/img/services/outgoing-webhook_36.png',
                        'blocks': messageBlock,
                    }

                    uploadFileData = {
                        'file': ('filename', open(dirname+filename, 'rb'), 'anx'),
                    }

                    uploadMessagePayload = {
                        'token': slackBotAccessToken,
                        'channels': self.slackAlertChannel,
                        'username': 'VATracker',
                        'filename': filename,
                        'filetype': 'anx',
                        'title': '{} i2 Chart'.format(txid)
                    }

                    requests.post('https://slack.com/api/chat.postMessage', params=alertMessagePayload)
                    requests.post('https://slack.com/api/files.upload', params=uploadMessagePayload, files=uploadFileData)

                    uploadFileData['file'][1].close()
                except Exception as e:
                    print('Error on make slack message')
                    print(traceback.format_exc())

            print(messageBlock)


        # 거래소로 입금된 경우
        #if address in txTo:
        # 임시, 타겟에서 출금하는 경우만 알림
        try:
            if exchange not in  ['', 'Unknown'] and txFrom in self.alertList:
                currentDatetime = datetime.fromtimestamp(int(time.time()))
                documentFileDateString = currentDatetime.strftime('%Y%m%d_%H%M%S')

                # 공문서 양식 만들기
                workbook = load_workbook(filename = self.requestDocument['filename'])
                worksheet = workbook.active
                worksheet['B6'] = currentDatetime
                worksheet['E9'] = exchange
                worksheet['C17'] = self.requestDocument['summary']
                worksheet['H23'] = txid
                worksheet['H24'] = txDatetimeString
                worksheet['H25'] = txFrom
                worksheet['H26'] = address
                worksheet['H27'] = txReceiveAmount[txTo.index(address)]
                worksheet['C42'] = self.requestDocument['contact']

                filename = '{}({})-{}.xlsx'.format(self.requestDocument['filename'].split('.')[0], exchange, documentFileDateString)
                if os.path.exists(filename):
                    time.sleep(1)

                workbook.save(filename)

                # 메일 보내기
                if self.sendEmailAlert and txToExchange in self.exchangeEmails:
                    gmail = GMailWorker('bugzero0203@gmail.com', 'truebwtdjvvmzums')

                    for emailAddress in self.exchangeEmails[exchangeName]:
                        message = Message('[Korean National Police Agency] Temporarily freeze request',
                                          sender=self.investigatorEmails[0],
                                          to=emailAddress,
                                          text=self.requestEmailContents,
                                          attachments=[filename])
                        gmail.send(message)

                    for emailAddress in self.investigatorEmails:
                        chartFilename = 'result/{}_{}/{}_{}.anx'.format(self.coin, self.target, self.coin, self.target)
                        message = Message('[BATS] Deposit Notification - {}'.format(exchange),
                                          sender=self.investigatorEmails[0],
                                          to=emailAddress,
                                          text=alertMessageForInvestigator,
                                          attachments=[chartFilename])
                        gmail.send(message)

                    gmail.close()
        except Exception as e:
            print('Error on make document')
            print(traceback.format_exc())

    def saveResultCSV(self):
        dirname = 'result/{}_{}'.format(self.coin, self.target)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)

        with open(dirname + '/result.csv', 'wt') as result:
            result.write('datetime,txid,block number,senders,receivers,amounts,totalAmount,fee\n')
            for txid in self.txData:
                txdata = self.txData[txid]
                receiverAmount = txdata['receiverAmount']

                result.write('{},{},{},{},{},{},{},{}\n'.format(datetime.fromtimestamp(txdata['timestamp']), txid, txdata['blocknumber'],
                                                             txdata['sender'], ';'.join(txdata['receiver']),
                                                             ';'.join(map(str, receiverAmount)), sum(receiverAmount), txdata['fee']))

        with open(dirname + '/target.csv', 'wt') as result:
            result.write('address,balance,exchange info,last block number\n')
            for address in self.targetList:
                target = self.targetList[address]
                result.write('{},{},{},{}\n'.format(address, 0 if target['balance'] == 0 else target['balance'], target['exchange'], target['lastblock']))

        # tmp log
        dirname = 'result/tmp/{}_{}'.format(self.coin, self.target)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)

        for address in self.txList:
            with open(dirname + '/%s.csv' % address, 'wt') as result:
                result.write('txid,timestamp\n')
                for txid in self.txList[address]:
                    result.write('{},{}\n'.format(txid, self.txList[address][txid]))

    def saveChart(self):
        dirname = 'result/{}_{}'.format(self.coin, self.target)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)

        chartDatas = [
            {'filename': '{}_{}.anx'.format(self.coin, self.target), 'data': self.targetList},
            {'filename': '{}_{}_onlySuspect.anx'.format(self.coin, self.target), 'data': list(set(self.alertList + highlight))}
        ]

        savedExchange = self.loadDictionary('load_exchange.csv')
        savedSuspect = self.loadDictionary('load_suspect.csv')

        for chartData in chartDatas:
            chart = pyanx.Pyanx()
            chartNode = {}

            for address in chartData['data']:
                exchangeInfo = self.targetList[address]['exchange']

                if address in savedExchange:
                    exchangeInfo = savedExchange[address]

                totalTxCount = len(self.txList[address])
                balance = self.targetList[address]['balance']
                lastblock = self.targetList[address]['lastblock']
                incomingTxCount = len([txid for txid in self.txList[address] if address in self.txData[txid]['receiver']])
                outgoingTxCount = len([txid for txid in self.txList[address] if address == self.txData[txid]['sender']])
                entity_type = self.coin if '' == exchangeInfo or self.target == address or address not in self.alertList else 'ccexchange' #exchangeInfo

                #description = '{}(balance {})'.format(self.coin if '' == exchangeInfo else exchangeInfo, '0' if balance == 0 else dropTailingZeros(str(balance)))
                description = ''
                if address in savedExchange:
                    description += savedExchange[address]
                elif address in savedSuspect:
                    description += savedSuspect[address]
                elif exchangeInfo != '':
                    description += exchangeInfo
                else:
                    description += self.coin

                if balance > 0:
                    description += ' (balance {})'.format(dropTailingZeros(str(balance)))

                ring_color = None
                icon_size = None

                isStartingAddr = address == self.target
                isExchangeAddr = '' != exchangeInfo
                isWatchingAddr = balance > 1 and not isExchangeAddr
                isEndpointAddr = incomingTxCount > 0 and outgoingTxCount == 0 and not isExchangeAddr
                isWhaleAddr = totalTxCount > 20
                isHighlight = address in self.highlight
                isAlertAddr = address in self.alertList

                if ((isStartingAddr or isWatchingAddr or isEndpointAddr or isExchangeAddr or isWhaleAddr) and lastblock > 0) or isHighlight or isAlertAddr:
                    icon_size = 'ICEnlargeTriple'


                if isWatchingAddr or (isEndpointAddr and lastblock > 0):
                    ring_color = 0

                if isHighlight:
                    ring_color = 590079

                if isAlertAddr:
                    ring_color = 4259648

                if isStartingAddr:
                    ring_color = 16711680

                chartNode[address] = chart.add_node(entity_type=entity_type, label=address, description=description, ring_color=ring_color, icon_size=icon_size)

            firstTimestamp = 0

            chartEdegeData = {}
            chartEdegeData.update(self.txData)

            for txid in chartEdegeData:
                txdata = chartEdegeData[txid]
                tzdata = timezone(timedelta(hours=9))
                tzstring = 'Asia/Seoul'
                dateformat = '%Y-%m-%dT%H:%M:%S%z'
                datestr = datetime.fromtimestamp(txdata['timestamp'], tzdata).strftime(dateformat)

                receiver = txdata['receiver']
                amount = txdata['receiverAmount']

                for i in range(len(receiver)):
                    if txdata['sender'] in chartNode and txdata['sender'] != receiver[i]:
                        try:
                            chart.add_edge(chartNode[txdata['sender']], chartNode[receiver[i]], label=txid, description=amount[i], datestr=datestr, dateformat=dateformat, timezone=tzstring)
                        except KeyError:
                            log.info('chartNode has no receiver {}'.format(receiver))

                firstTimestamp = txdata['timestamp'] if 0 == firstTimestamp else min(firstTimestamp, txdata['timestamp'])

            if self.linkFrom and self.linkFrom not in self.targetList:
                tzdata = timezone(timedelta(hours=9))
                tzstring = 'Asia/Seoul'
                dateformat = '%Y-%m-%dT%H:%M:%S%z'
                datestr = datetime.fromtimestamp(firstTimestamp - 1, tzdata).strftime(dateformat)

                chartNode[self.linkFrom] = chart.add_node(entity_type='Account', label=self.linkFrom)
                chart.add_edge(chartNode[self.linkFrom], chartNode[self.target], datestr=datestr, dateformat=dateformat, timezone=tzstring)

            chart.create(dirname + '/' + chartData['filename'])


    def loadDictionary(self, filename):
        suspectDict = {}
        with open(filename, 'rt') as suspect:
            for linedata in suspect.readlines():
                suspectData = linedata.replace('\n', '')
                if len(suspectData):
                    suspectDict[suspectData.split(',')[0].lower()] = suspectData.split(',')[1].replace('\n', '')
        return suspectDict

    def saveAlertList(self):
        suspectsBalance = Decimal(str(0))
        with open('saved_alert.csv', 'wt') as suspect:
            suspectDict = self.loadDictionary('load_suspect.csv')
            suspectDict.update(self.loadDictionary('load_exchange.csv'))
            for address in self.alertList:
                exchange = ''
                if address in suspectDict:
                    exchange = suspectDict[address]
                elif self.targetList[address]['exchange'] != '':
                    exchange = self.targetList[address]['exchange']

                if exchange == '' or exchange[:5] == 'Upbit':
                    suspectsBalance += Decimal(self.targetList[address]['balance'])
                suspect.write('{},{},{}\n'.format(address, self.targetList[address]['balance'], exchange))
        return suspectsBalance


        '''
        targetList = {
            address: {
                'balance': 0,
                'exchange': '',
                'lastblock': 0,
            },
        }
        txList = {
            address: {
                txid1: timestamp1,
                txid2: timestamp2,
            },
        }
        txData = {
            txid: {
                'timestamp': 0,
                'blocknumber': 0,
                'senders': ['0'],
                'senderAmount': [0.0],
                'receivers': ['0'],
                'receiverAmounts': [0.0],
                'fee': 0.0,
            },
        }

        '''