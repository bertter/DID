from tracker_eth import ETHTracker
from tracker_eth_api import ETHAPITracker
from tracker_btc import BTCTracker
from tracker_trx import TRXTracker
from tracker_xrp import XRPTracker
from tracker_qtum import QTUMTracker

tracker = {
	'ETH': ETHTracker,
	'BTC': BTCTracker,
	'TRX': TRXTracker,
	'XRP': XRPTracker,
	'QTUM': QTUMTracker,
}