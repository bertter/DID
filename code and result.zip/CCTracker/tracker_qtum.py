import asyncio
import time, datetime
from decimal import Decimal
from bs4 import BeautifulSoup

from tracker_base import Tracker
from utils import dropTailingZeros
from logger import log
import traceback

import pprint

class QTUMTracker(Tracker):
	def __init__(self, coin, target, datasrc, linkFrom, apikeyStore, delay, debug):
		super().__init__(coin, target, datasrc, linkFrom, delay, debug)

	async def getExchangeInfo(self, target):
		queryString = 'SELECT owner FROM cctracker.{} WHERE address = "{}"'.format(self.tableName['owner'], target)
		exchangeInfo = await self.dbManager.dbExecute(queryString)
		if exchangeInfo:
			return exchangeInfo[0][0]
		else:
			return ''

	async def getTransactionCount(self, target):
		clusterId = await self.getClusterId([target])

		queryString = 'SELECT address, send, receive FROM {} WHERE cid = {}'.format(self.tableName['address'], clusterId[target])
		if clusterId[target] == -1:
			queryString = 'SELECT address, send, receive FROM {} WHERE address = "{}"'.format(self.tableName['address'], target)
		transDatasFromDB = await self.dbManager.dbExecute(queryString)
		transDatas = {}

		for transData in transDatasFromDB:
			(address, send, receive) = transData
			transDatas[address] = len(list(set(send.split(',') + receive.split(','))))

		transCount = sum(transDatas.values())

		return transCount

	async def getBalance(self, target):
		clusterId = await self.getClusterId([target])

		queryString = 'SELECT address, balance FROM {} WHERE cid = {}'.format(self.tableName['address'], clusterId[target])
		if clusterId[target] == -1:
			queryString = 'SELECT address, balance FROM {} WHERE address = "{}"'.format(self.tableName['address'], target)
		balanceDatasFromDB = await self.dbManager.dbExecute(queryString)
		balanceDatas = {}

		for balanceData in balanceDatasFromDB:
			(address, balance) = balanceData
			balanceDatas[address] = balance

		balance = Decimal(sum(balanceDatas.values()))

		return balance

	async def getTransactionData(self, target, limit, lastBlock = 0, currentTxCount = 0):
		queryString = 'SELECT send, receive FROM {} WHERE address = "{}"'.format(self.tableName['address'], target)
		result = await self.dbManager.dbExecute(queryString)

		txlist = {}
		if 0 < len(result[0][0]) or 0 < len(result[0][1]):
			txNums = list(set(result[0][0].split(',') + result[0][1].split(',')))
			if '' in txNums:
				txNums.remove('')

			txIdDict = await self.getTransactionIds(txNums)
			txNumDict = { v: int(k) for k, v in txIdDict.items() } #txnum 이 value

			queryString = 'SELECT txid, blocknum, txtime, sender, sender_amount, receiver, receiver_amount FROM `{}` WHERE blocknum > {} AND txid in ("{}")'.format(
				self.tableName['transaction'], lastBlock, '","'.join(map(str, list(txNumDict.keys()))))
			transDatasFromDB = await self.dbManager.dbExecute(queryString)

			transDatas = {}
			for transData in transDatasFromDB:
				(txid, blocknum, timestamp, sender, senderAmount, receiver, receiverAmount) = transData
				sender = [] if 0 == len(sender) else sender.split(',')
				receiver = [] if 0 == len(receiver) else receiver.split(',')

				clusterIdList = await self.getClusterId(sender + receiver)
				senderClusterId = clusterIdList[sender[0]]
				senderClusterInfo = await self.getClusterInfo(senderClusterId)

				receiverClusterIdList = list(set(clusterIdList.values()))
				receiverClusterIdList.remove(senderClusterId)
				receiverClusterInfo = await self.getClusterInfo(receiverClusterIdList)

				senderAmount = Decimal('0') if 0 == len(senderAmount) else list(map(Decimal, map(str, senderAmount.split(','))))
				receiverAmount = Decimal('0') if 0 == len(receiverAmount) else list(map(Decimal, map(str, receiverAmount.split(','))))
				txFee = sum(senderAmount) - sum(receiverAmount)

				##print(target, receiver)
				# receiver 목록에서 sender 제외
				if senderClusterId > -1:
					receiver_ = []
					receiverAmount_ = []
					for i in range(len(receiver)):
						if clusterIdList[receiver[i]] != senderClusterId:
							receiver_.append(receiver[i])
							receiverAmount_.append(receiverAmount[i])
					receiver = receiver_
					receiverAmount = receiverAmount_

				##print(target, receiver)
				# receiver, receiverAmount 를 cid 기준으로 병합
				if len(receiverClusterInfo) > 0:
					receiverMerge = {}
					for cid in receiverClusterInfo:
						masterAddress = receiverClusterInfo[cid]['master']
						if masterAddress not in receiverMerge:
							receiverMerge[masterAddress] = 0

						for i in range(len(receiver)):
							if clusterIdList[receiver[i]] == -1:
								receiverMerge[receiver[i]] = receiverAmount[i]
								continue

							if clusterIdList[receiver[i]] == cid:
								receiverMerge[receiverClusterInfo[cid]['master']] += receiverAmount[i]
					else:
						receiver = list(receiverMerge.keys())
						receiverAmount = list(receiverMerge.values())

				##print(target, receiver)

				# return data 조합
				timestamp = int(time.mktime(timestamp.timetuple()))
				transDatas[txid] = {}
				transDatas[txid]['timestamp'] = timestamp
				transDatas[txid]['blocknumber'] = blocknum
				transDatas[txid]['fee'] = txFee

				if target in sender:
					transDatas[txid]['sender'] = target
				else:
					if senderClusterInfo:
						transDatas[txid]['sender'] = senderClusterInfo[senderClusterId]['master']
					else:
						transDatas[txid]['sender'] = sender[0]
				transDatas[txid]['senderAmount'] = senderAmount

				transDatas[txid]['receiver'] = receiver
				transDatas[txid]['receiverAmount'] = receiverAmount


			#pprint.pprint(transDatas)
			#input()
			return transDatas

	async def getClusterId(self, addressList):
		if not isinstance(addressList, list):
			addressList = [addressList]

		queryString = 'SELECT address, cid FROM {} WHERE address in ("{}")'.format(self.tableName['address'], '","'.join(list(set(addressList))))
		clusterIdListFromDB = await self.dbManager.dbExecute(queryString)
		clusterIdList = {}

		for clusterData in clusterIdListFromDB:
			(address, cid) = clusterData
			clusterIdList[address] = cid

		return clusterIdList

	async def getClusterInfo(self, clusterIdList):
		if not isinstance(clusterIdList, list):
			if clusterIdList == -1:
				return []
			else:
				clusterIdList = [clusterIdList]
		elif isinstance(clusterIdList, list):
			if len(clusterIdList) == 0:
				return []
			elif len(clusterIdList) == 1 and clusterIdList[0] == -1:
				return []
			elif -1 in clusterIdList:
				clusterIdList.remove(-1)

		queryString = 'SELECT cid, master, first_txtime, last_txtime FROM {} WHERE cid in ({})'.format(self.tableName['clustering'], ','.join(list(map(str, clusterIdList))))
		clusterInfoFromDB = await self.dbManager.dbExecute(queryString)
		clusterInfoList = {}

		for clusterInfo in clusterInfoFromDB:
			(cid, master, first_txtime, last_txtime) = clusterInfo
			clusterInfoList[cid] = {
				'master': master,
				'first_txtime': first_txtime,
				'last_txtime': last_txtime,
			}

		return clusterInfoList

	async def getTransactionIds(self, txnum):
		txnum_ = list(map(str, txnum))
		queryString = 'SELECT txnum, txid FROM {} WHERE txnum in ("{}")'.format(self.tableName['txnum'], '","'.join(txnum_))
		transactionsNumberFromDB = await self.dbManager.dbExecute(queryString)
		transactionsNumber = { data[0]: data[1] for data in transactionsNumberFromDB } # TXNUM: TXID
		return transactionsNumber