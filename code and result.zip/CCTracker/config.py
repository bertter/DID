slackWebHookURL = 'https://hooks.slack.com/services/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' # 1팀 테스트 채널
slackWebHookURL = 'https://hooks.slack.com/services/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' # 2팀 U사 케이스
slackWebHookURL = 'https://hooks.slack.com/services/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' # 2020 2team DDOS
#slackAccessToken = 'xoxp-851032311664-853240086902-855280190261-fd7416ca49686f38df816d93c6a46443'
slackBotAccessToken = 'xoxb-535997994677-1351867384229-PziWY3D2E5VBARtKvaz536LS'
slackAlertChannel = '#tracker_ddos'

gmailUsername    = 'bugzero0203@gmail.com'
gmailAPPPassword = 'truebwtdjvvmzums'

# 나간갯수로만 제한 걸도록 수정
transactionLimits = {
    'QTUM': 10,
    'ETH': 1000,
    'BTC': 50,
    'TRX': 50,
    'XRP': 50,
}

# 차트에서 감시 태그 붙여줄 잔고 갯수
watchingBalances = {
    'QTUM': 50,
    'ETH': 1,
    'BTC': 1,
    'TRX': 100,
    'XRP': 100,
}

apikey = {
    'ETH': ['68P55WI2UKYJ2FKQKYJ8T92KPJJNNKJH2N',
            'X5WZ9FDVWG6B7I68779PFN39BQVQ9AVPAI',
            '7J9Q4QDGMA9877AW4YIPHZMHRBJJKDD5D7',
            '6U7UWEKX6S23DDPXPJYBQD41QSHTQCNY9D',
            '8SICA9WXTS1DEQCUBYZJ55C3NWQA5EM66J',
            'Q3HSEJZTFT8VH3QSR3GDYJQE4JWQN172QY',
            'QNHWH3IN6WDNI9DE52FGMJKAGHNDXQ5TZA',
            'DUS1X5E82PC5PH9ZV5GPST9HJEG1ACJJ5E',
            '2T7CN8MPCRGAS3GAWF7XV8IQT8SME17V5D',
            'NTRDHEN112Q89EFWFU6PIN49BCVG1WEKIX'],
    'BTC': ['YourApiKeyToken'],
}

target = [
    #(SYNBOL, ADDRESS, DATASRC, DELAY, LINK, DEBUG),
    #('QTUM', 'MCLtesVhftuQvYYtANARANYarW1zgxXNx6', 'DB', 5, None, False),
    #('QTUM', 'M8DnjbvCxgq4uXBZ6kgasREhLsVqWV5Znv', 'DB', 5, None, False),
    #('QTUM', 'QYMfqCRkMcM6pCUYEjrFwAiqH8Yai6Qc29', 'DB', 5, None, False),
    #('ETH', '0x283f0c9e177b2656ad534ecc9a00543a6ff60379', 'DB', 10, None, False),
    #('ETH', '0x05817b2df6d70b844f1a6197e6f699ed92af360e', 'DB', 10, '0x283f0c9e177b2656ad534ecc9a00543a6ff60379', True),
    ##('ETH', '0xa09871aeadf4994ca12f5c0b6056bbd1d343c029', 'DB', 10, None, True),
    #('TRX', 'TDU1uJNxDND9zhzYjnn7ZunHj18jw7oAca', 'API', 60, None, False),
    #('XRP', 'rnNgELQYzRZS9aGjvQo1dXUKuPK5PybPaM', 'API', 60, None, False),
    #('XRP', 'rfVingZtoqT4ExnCqgTadEyCSqQWkekeys', 'API', 60, None, False),
    #('BTC', '1MgAK1nnLE1zGDSSGdGk1Av2yrNMvbxrcY', 'DB', 1, None, False),
    ('BTC', '14tyHh6wnswf1hWknL7zPyGNPr2tXB7wQa', 'DB', 60, None, False),
    ('BTC', '1CFvoHuW8KUfq1JmncogbK7hg3PxKMB1fn', 'DB', 60, None, False),
    ('BTC', '1CYCBookffKUt8PxX8oBrWSD39HS8eSo8Z', 'DB', 60, None, False),
    ('BTC', '1NmbLhvzrvQD3HDW8ojaxq21jG5ykMWpXQ', 'DB', 60, None, False),
]

highlight = ['1MgAK1nnLE1zGDSSGdGk1Av2yrNMvbxrcY']

investigatorEmails = ['bugzero@police.go.kr']
exchangeEmails = {
    'huobi': ['tanboyue@huobi.com', 'Josh.Goodbody@huobi.com', 'lihaoda@huobi.com', 'lvjiayin@huobi.com', 'zhengguanjiong@huobi.com', 'jiyun@huobi.com', 'liangwei@huobi.com', 'liaokai@huobi.com', 'support@huobi.com'],
    'bitfinex': ['inforequests@bitfinex.com', 'shann.lu@bitfinex.com', 'fara.fallah@bitfinex.com'],
    'binance': ['case@binance.com', 'jerry.zheng@binance.com'],
    'exmo': ['corporate@exmo.com', 'striukova.e@exmo.com', 'legal@exmo.com'],
    'changelly': ['legal@changelly.com'],
    'changenow': ['support@changenow.io'],
    'bwcom': ['ponyc@bw.io', 'yomi@bw.io', 'support@bw.com'],
    'hitbtc': ['oleg@hitbtc.com', 'legal@hitbtc.com', 'support@hitbtc.zendesk.com'],
    'coinswitch': ['support@coinswitch.co'],
    'yobit': ['security@yobit.net'],
    'bitforex': ['zhuyibin@bitforex.com', 'support@bitforex.com', 'report@bitforex.com', 'feedback@bitforex.com', 'support_kr@bitforex.com'],
    'kucoin': ['support@kucoin.com', 'legal@kucoin.com'],
    'bibox': ['support@bibox.zendesk.com'],
}

requestEmailContents = '''
Dear Exchange

This is an automatic e-mail sent from Korean National Police Agency when suspicious transactions are detected.

We respectfully request you to temporarily freeze wallet addresses in the excel attachment. Those wallet addresses are strongly related to the crime we are investigating.

We will send you the official document and investigator’s ID card within 24 hours. Or you could suggest us the requirements for freezing. Before than please maintain the freezing for preventing further withdrawal.

Thanks for you cooperation.

Best regards
Korean National Police Agency.
'''

requestDocument = {}
requestDocument['filename'] = 'doc/RequestDocument.xlsx'
requestDocument['contact'] = '''
GyeongMin Baek, Investigator
Cyber Terror Investigation Team, Cyber Bureau, Korean National Police Agency
Tel : + 82 2 3150 0046            Fax : + 82 2 3150 3796
E-Mail : bugzero@police.go.kr
'''
requestDocument['summary'] = '  ' + 'Unknown suspects intruded on the South Korea’s cryptocurrency exchange market(upbit.com) on 27 Nov 2019 and took over cryptocurrency worth about 49,400,000 USD.'