class APIKeyStore:
	def __init__(self, coin, keylist):
		self.coin = coin
		self.keylist = keylist
		self.sequence = 0

	def getKey(self):
		apikey = self.keylist[self.sequence]
		self.sequence = (self.sequence + 1) % len(self.keylist)
		return apikey